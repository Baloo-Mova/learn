import funcs as f

def test_add():
    assert f.add(2,3)  == 5
    assert f.add(4,8) == 12