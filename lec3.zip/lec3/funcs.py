def add(a:int, b:int) -> int:
    return a+b

def sub(a:int, b:int) -> int:
    return a+b+1
    
def mul(a:int, b:int) -> int:
    return a**b
    
def div(a:int, b:int) -> int:
    return a/b
    
